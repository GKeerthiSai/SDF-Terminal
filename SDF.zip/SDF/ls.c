#include<stdio.h>
#include<dirent.h>
#include<sys/stat.h>
#include<unistd.h>
#include<string.h>
#include<math.h>
#include<readline/history.h>
#include<readline/readline.h>
#include<stdlib.h>
#include<grp.h>
#include<pwd.h>
struct fp{
  struct stat files;
  char file[500];
  };
  // ls -a ---> files including . files
  //ls  ---->files without including hidden files
int sorting(const void *a,const void *b){ //ls -l
  struct fp* pa=(struct fp*) a;
  struct fp* pb=(struct fp*)b;
  return strcasecmp(pa->file,pb->file);
}
int timing(const void *a,const void *b){ // ls -t
  struct fp* pa=(struct fp*) a;
  struct fp* pb=(struct fp*)b;
  return (pb->files.st_mtime)-(pa->files.st_mtime);
}
int sizes(const void *a,const void *b){  //ls -S
  struct fp* pa=(struct fp*) a;
  struct fp* pb=(struct fp*)b;
  return (pb->files.st_size)-(pa->files.st_size);
}





void lstotal(char* command){
char *store[100];
        char copy[200];
        copy[0]='\0';int k=0;
        char *parse = strtok(command," ");
        while(parse != NULL){
        
        store[k]=parse;
        parse = strtok(NULL," ");
       
        k++;
       }
      strcat(copy,store[0]);
       strcat(copy," ");
       strcat(copy,store[1]);


   if(strcmp(copy,"ls -l")==0)
   {
struct dirent *dr;
int i=0;int count=0;
char filename[300];
struct passwd *pwd;
struct group *grp;
char time[100];
DIR *dir=opendir(".");
if(dir==NULL){
printf("Cannot open the directory\n");
}
while((dr = readdir(dir)) != NULL) {
    if(dr->d_name[0]!='.'){
           count++;
    }
    }
struct fp myprop[count];
rewinddir(dir);
while((dr = readdir(dir)) != NULL) {
    if(dr->d_name[0]!='.'){
    strcpy(myprop[i].file,dr->d_name);
    sprintf(filename,"./%s",dr->d_name);
    stat(filename,&myprop[i].files);
    
    i++;
    }
  } 
qsort(myprop,count,sizeof(struct fp),sorting);
for(i=0;i<count;i++){
pwd = getpwuid(myprop[i].files.st_uid);
  grp = getgrgid(myprop[i].files.st_gid);
  strftime(time, 100, "%b %d %H:%M", localtime(&myprop[i].files.st_mtime));
  printf( (S_ISDIR(myprop[i].files.st_mode)) ? "d" : "-"); 
printf( (myprop[i].files.st_mode & S_IRUSR) ? "r" : "-");
printf( (myprop[i].files.st_mode & S_IWUSR) ? "w" : "-");
printf( (myprop[i].files.st_mode & S_IXUSR) ? "x" : "-"); 
printf( (myprop[i].files.st_mode & S_IRGRP) ? "r" : "-"); 
printf( (myprop[i].files.st_mode & S_IWGRP) ? "w" : "-");
printf( (myprop[i].files.st_mode & S_IXGRP) ? "x" : "-");
printf( (myprop[i].files.st_mode & S_IROTH) ? "r" : "-");
printf( (myprop[i].files.st_mode & S_IWOTH) ? "w" : "-");
printf( (myprop[i].files.st_mode & S_IXOTH) ? "x" : "-");
printf("\t");
printf("%ld",myprop[i].files.st_nlink);
printf("\t");
printf("%s",pwd->pw_name);
printf("\t");
printf("%s",grp->gr_name);
printf("\t");
printf("%ld",myprop[i].files.st_size);
printf("\t");
printf("%s",time);
printf("\t");
printf("%s",myprop[i].file);
printf("\n");
}
}
else if(strcmp(copy,"ls -t")==0){
struct dirent *dr;
int i=0;int count=0;
char filename[300];
struct passwd *pwd;
struct group *grp;
char time[100];
DIR *dir=opendir(".");
if(dir==NULL){
printf("Cannot open the directory\n");
}
while((dr = readdir(dir)) != NULL) {
    if(dr->d_name[0]!='.'){
           count++;
    }
    }
struct fp myprop[count];
rewinddir(dir);
while((dr = readdir(dir)) != NULL) {
    if(dr->d_name[0]!='.'){
    strcpy(myprop[i].file,dr->d_name);
    sprintf(filename,"./%s",dr->d_name);
    stat(filename,&myprop[i].files);
    
    i++;
    }
  } 
qsort(myprop,count,sizeof(struct fp),timing);
for(i=0;i<count;i++){
pwd = getpwuid(myprop[i].files.st_uid);
  grp = getgrgid(myprop[i].files.st_gid);
  strftime(time, 100, "%b %d %H:%M", localtime(&myprop[i].files.st_mtime));
  printf( (S_ISDIR(myprop[i].files.st_mode)) ? "d" : "-"); 
printf( (myprop[i].files.st_mode & S_IRUSR) ? "r" : "-");
printf( (myprop[i].files.st_mode & S_IWUSR) ? "w" : "-");
printf( (myprop[i].files.st_mode & S_IXUSR) ? "x" : "-"); 
printf( (myprop[i].files.st_mode & S_IRGRP) ? "r" : "-"); 
printf( (myprop[i].files.st_mode & S_IWGRP) ? "w" : "-");
printf( (myprop[i].files.st_mode & S_IXGRP) ? "x" : "-");
printf( (myprop[i].files.st_mode & S_IROTH) ? "r" : "-");
printf( (myprop[i].files.st_mode & S_IWOTH) ? "w" : "-");
printf( (myprop[i].files.st_mode & S_IXOTH) ? "x" : "-");
printf("\t");
printf("%ld",myprop[i].files.st_nlink);
printf("\t");
printf("%s",pwd->pw_name);
printf("\t");
printf("%s",grp->gr_name);
printf("\t");
printf("%ld",myprop[i].files.st_size);
printf("\t");
printf("%s",time);
printf("\t");
printf("%s",myprop[i].file);
printf("\n");
}
}
else if(strcmp(copy,"ls -S")==0)
   {
struct dirent *dr;
int i=0;int count=0;
char filename[300];
struct passwd *pwd;
struct group *grp;
char time[100];
DIR *dir=opendir(".");
if(dir==NULL){
printf("Cannot open the directory\n");
}
while((dr = readdir(dir)) != NULL) {
    if(dr->d_name[0]!='.'){
           count++;
    }
    }
struct fp myprop[count];
rewinddir(dir);
while((dr = readdir(dir)) != NULL) {
    if(dr->d_name[0]!='.'){
    strcpy(myprop[i].file,dr->d_name);
    sprintf(filename,"./%s",dr->d_name);
    stat(filename,&myprop[i].files);
    
    i++;
    }
  } 
qsort(myprop,count,sizeof(struct fp),sizes);
for(i=0;i<count;i++){
pwd = getpwuid(myprop[i].files.st_uid);
  grp = getgrgid(myprop[i].files.st_gid);
  strftime(time, 100, "%b %d %H:%M", localtime(&myprop[i].files.st_mtime));
  printf( (S_ISDIR(myprop[i].files.st_mode)) ? "d" : "-"); 
printf( (myprop[i].files.st_mode & S_IRUSR) ? "r" : "-");
printf( (myprop[i].files.st_mode & S_IWUSR) ? "w" : "-");
printf( (myprop[i].files.st_mode & S_IXUSR) ? "x" : "-"); 
printf( (myprop[i].files.st_mode & S_IRGRP) ? "r" : "-"); 
printf( (myprop[i].files.st_mode & S_IWGRP) ? "w" : "-");
printf( (myprop[i].files.st_mode & S_IXGRP) ? "x" : "-");
printf( (myprop[i].files.st_mode & S_IROTH) ? "r" : "-");
printf( (myprop[i].files.st_mode & S_IWOTH) ? "w" : "-");
printf( (myprop[i].files.st_mode & S_IXOTH) ? "x" : "-");
printf("\t");
printf("%ld",myprop[i].files.st_nlink);
printf("\t");
printf("%s",pwd->pw_name);
printf("\t");
printf("%s",grp->gr_name);
printf("\t");
printf("%ld",myprop[i].files.st_size);
printf("\t");
printf("%s",time);
printf("\t");
printf("%s",myprop[i].file);
printf("\n");
}
}else if(strcmp(copy,"ls -a")==0)
   {
struct dirent *dr;
int i=0;int count=0;
char filename[300];
struct passwd *pwd;
struct group *grp;
char time[100];
DIR *dir=opendir(".");
if(dir==NULL){
printf("Cannot open the directory\n");
}
while((dr = readdir(dir)) != NULL) {
   // if(dr->d_name[0]!='.'){
           count++;
    //}
    }
struct fp myprop[count];
rewinddir(dir);
while((dr = readdir(dir)) != NULL) {
   // if(dr->d_name[0]!='.'){
    strcpy(myprop[i].file,dr->d_name);
    sprintf(filename,"./%s",dr->d_name);
    stat(filename,&myprop[i].files);
    
    i++;
    //}
  } 
qsort(myprop,count,sizeof(struct fp),sorting);
for(i=0;i<count;i++){
pwd = getpwuid(myprop[i].files.st_uid);
  grp = getgrgid(myprop[i].files.st_gid);
  strftime(time, 100, "%b %d %H:%M", localtime(&myprop[i].files.st_mtime));
printf("%s",myprop[i].file);
printf("\n");
}
}
else if(strcmp(store[0],"ls")==0)
   {
struct dirent *dr;
int i=0;int count=0;
char filename[300];
struct passwd *pwd;
struct group *grp;
char time[100];
DIR *dir=opendir(".");
if(dir==NULL){
printf("Cannot open the directory\n");
}
while((dr = readdir(dir)) != NULL) {
    if(dr->d_name[0]!='.'){
           count++;
    }
    }
struct fp myprop[count];
rewinddir(dir);
while((dr = readdir(dir)) != NULL) {
   if(dr->d_name[0]!='.'){
    strcpy(myprop[i].file,dr->d_name);
    sprintf(filename,"./%s",dr->d_name);
    stat(filename,&myprop[i].files);
    
    i++;
    }
  } 
qsort(myprop,count,sizeof(struct fp),sorting);
for(i=0;i<count;i++){
pwd = getpwuid(myprop[i].files.st_uid);
  grp = getgrgid(myprop[i].files.st_gid);
  strftime(time, 100, "%b %d %H:%M", localtime(&myprop[i].files.st_mtime));
printf("%s",myprop[i].file);
printf("\n");
}
}

else{
printf("Command not found\n");}


}

















  
