#include<stdio.h>
#include<sys/stat.h>		
#include<readline/readline.h> 
#include<readline/history.h> 		
#include<dirent.h>
#include<string.h>
#include<pwd.h>
#include<grp.h>
#include<math.h>
#include<unistd.h>
void ps(char* );
struct fp{
  struct stat files;
  char file[500];
  };

void pstotal(char* command,char *username){
		
if(strcmp(command,"ps")==0){
     	
	DIR *dir=opendir("/proc");
	char processid[300],cmd[200];
	struct dirent *dr;
	char time[100];int i=0;
	char filename[500];
	struct passwd *pwd;
        struct group *grp;
	printf("\tPID\tTTY\tTIME\tCMD");
	while((dr=readdir(dir))!=NULL)
		{
		struct fp my_prop[i];
    if(dr->d_name[0]!='.'){
    strcpy(my_prop[i].file,dr->d_name);
    sprintf(filename,"./%s",dr->d_name);
    stat(filename,&my_prop[i].files);
    i++;
    }
   

		strftime(time, 100, "%b %d %H:%M", localtime(&my_prop[i].files.st_mtime));
			pwd = getpwuid(my_prop[i].files.st_uid);
			grp = getgrgid(my_prop[i].files.st_gid);	
			strcpy(processid,dr->d_name);
			
			
			//if(strcmp(processid,username)!=0)
				//continue;
			
			printf("\n%s",dr->d_name);
			
			printf("%s",pwd->pw_name);
			//printf("%s",time);
			strcpy(cmd,dr->d_name);
			//ps_cmd(cmd);
			printf("\t%s",cmd);
		
}
printf("\n");}
}
