 #include<stdio.h>
#include<dirent.h>
#include<sys/stat.h>
#include<unistd.h>
#include<string.h>
#include<math.h>
#include<readline/history.h>
#include<readline/readline.h>
#include<stdlib.h>
void greptotal(char* command){
        int line_no=0;
        int i=0,count=0;
        FILE *fp;
        char line[200];
        int no_of_files=0;
        char *store[100];
        char copy[200];
        copy[0]='\0';
        
        
        char *parse = strtok(command," ");
        while(parse != NULL){
        
        store[i]=parse;
        parse = strtok(NULL," ");
        no_of_files++;
        i++;
       } 
      int n=no_of_files-2;      
       strcat(copy,store[0]);
       strcat(copy," ");
       strcat(copy,store[1]);
         
  if(strcmp(copy,"grep -v")==0){
  for(i=3;i<no_of_files;i++){
     fp=fopen(store[i],"r");
     printf("-----%s----\n",store[i]);
if(fp==NULL){
    printf("Given file cannot be found\n");
}
  while(fgets(line,100,fp)!=NULL){
    
    if(strstr(line,store[2])==NULL){     
        printf("%s\n",line);
       }
 }fclose(fp);
}
 }
 else if(strcmp(copy,"grep -c")==0){
 for(i=3;i<no_of_files;i++){
 fp=fopen(store[i],"r");
 printf("%s\n",store[i]);
if(fp==NULL){
    printf("Given file cannot be found\n");
}
  while(fgets(line,100,fp)!=NULL){
    line_no++;
    if(strstr(line,store[2])!=NULL){     
        count++;
       }
 }printf("Count is:%d\n",count);
 fclose(fp);
 }
 }
 
 else if(strcmp(copy,"grep -n")==0){
 for(i=3;i<no_of_files;i++){
 fp=fopen(store[i],"r");
 printf("%s\n",store[i]);
if(fp==NULL){
    printf("Given file cannot be found\n");
} line_no=0;
  while(fgets(line,100,fp)!=NULL){
    line_no++;
    if(strstr(line,store[2])!=NULL){     
      printf("%d: %s",line_no,line);  
       }
 }
 fclose(fp);
 }
 }
 else if(strcmp(copy,"grep -r")==0){
 for(i=3;i<no_of_files;i++){
 fp=fopen(store[i],"r");
 
 printf("%s: ",store[i]);
if(fp==NULL){
    printf("Given file cannot be found\n");
} line_no=0;
  while(fgets(line,100,fp)!=NULL){
    line_no++;
    if(strstr(line,store[2])!=NULL){     
      printf("%s",line);  
       }
 }
 fclose(fp);
 }
 }
 
 
 else if(strncmp(copy,"grep",4)==0){
  for(i=2;i<no_of_files;i++){
     fp=fopen(store[i],"r");
     
     if(fp==NULL){
         printf("Given file cannot be found\n");
         }
  while(fgets(line,100,fp)!=NULL){
   // line_no++;
    if(strstr(line,store[1])!=NULL){     
        printf("%s: %s\n",store[i],line);
       
       }
      
 }fclose(fp);
 }
 }
 
  }  

 
        
        
        
        
        
        
       
        
