#include<stdio.h>
#include<dirent.h>
#include<sys/stat.h>
#include<unistd.h>
#include<string.h>
#include<math.h>
#include<readline/history.h>
#include<readline/readline.h>
#include<stdlib.h>
#include<grp.h>
#include<pwd.h>
void lstotal(char* );
void cptotal(char* );
void mvtotal(char* );
void greptotal(char* );
void pstotal(char* ,char* );
int main( ){

 char hostname[100],cwd[50],displayname[200];
        char *username=getlogin();
        char *command;
        
        gethostname(hostname,100);
        getcwd(cwd,50);
        while(1){
        
         
        sprintf(displayname,"%s@%s:~%s$ ",getlogin(),hostname,cwd);
         
         command=readline(displayname);
        if(strlen(command)>0){
        add_history(command);}
        
  if(strcmp(command,"exit")==0){
        break;}
        FILE *src_file,*dstn_file;
        char ch;
        int k=0;
        
 if(strncmp(command,"ls",2)==0){
         lstotal(command);
       }
       
 else if(strncmp(command,"cp",2)==0){
      cptotal(command);     
     }
 else if(strncmp(command,"mv",2)==0){
     mvtotal(command);
     }
 else if(strncmp(command,"grep",4)==0){
    greptotal(command);
    }
 else if(strncmp(command,"ps",2)==0){
    pstotal(command,username);
   }
 else if(strcmp(command,"help")==0){
 printf("COMMAND NAME---LS\n");
 printf(" ls - list directory contents\n");
 printf(" SYNOPSIS \n");
 printf("ls -a      --all do not ignore entries starting with ");
  printf("ls -l     use a long listing format  ");
  printf("ls -S     sort by file size, largest first  ");           
printf("ls -t       sort by time, newest first; see --time  ");
 printf("COMMAND NAME-----CP\n  ");
 printf("cp - copy files and directories  ");
 printf("cp -n     do not overwrite an existing file (overrides a previous -i option)  ");
 printf("cp -f     --force\nif an existing destination file cannot be opened, remove it and try again (this option is ignored when the -n option is also used) ");
 printf(" cp -i    --interactive\nprompt before overwrite (overrides a previous -n option) ");
 printf("cp -u      --update\ncopy only when the SOURCE file is newer than the destination file or when the destination file is missing  ");
 printf(" COMMAND NAME-----MV\n  ");
 printf("mv -f --force\ndo not prompt before overwriting  ");
 printf("mv -i   --interactive\nprompt before overwrite");
 printf("mv -n   --no-clobber\n do not overwrite an existing file  ");
 printf("mv -u, --update\n move only when the SOURCE file is newer than the destination file or when the destination file is missing  ");
 printf(" COMMAND NAME-----grep\n  ");
 printf("grep -v   Invert the sense of matching, to select non-matching lines  ");
 printf("grep -c Suppress normal output; instead print a count of matching lines for each input file.  With the -v, --invert-match option  (see  below),  count non-matching lines.  ");
 printf("grep -n   Prefix each line of output with the 1-based line number within its input file.  ");
 printf("grep -r Read all files under each directory, recursively, following symbolic links only if they are on the command line.  Note that if no file operand  is given, B<grep> searches the working directory.  This is equivalent to the -d recurse option.  ");
 printf("COMMAND NAME--ps ");
 printf("Read all files under each directory, recursively, following symbolic links only if they are on the command line.  Note that if no file operand  is given, B<grep> searches the working directory.  This is equivalent to the -d recurse option.  ");
 
 }
   else{
   printf("%s:command not found\n",command);
   }
     }
    return 0; 
  }       










 
