#include<stdio.h>
#include<dirent.h>
#include<sys/stat.h>
#include<unistd.h>
#include<string.h>
#include<math.h>
#include<readline/history.h>
#include<readline/readline.h>
#include<stdlib.h>
void mvtotal(char* command){
        char copy[200];
        copy[0]='\0';
        FILE *src_file,*dstn_file;
        char response;
        char ch;
        int i=0;
        char *store[100];
        char *parse = strtok(command," ");
        while(parse != NULL){
        
        store[i]=parse;
        parse = strtok(NULL," ");
        
       
        i++;
       }
       strcat(copy,store[0]);
       strcat(copy," ");
       strcat(copy,store[1]);
       
 if(strcmp(copy,"mv -i")==0){
struct stat prop;char a;
if(stat(store[i-1],&prop)==0  &&  S_ISDIR(prop.st_mode)){
     if(stat(store[2],&prop) ==0 &&  S_ISDIR(prop.st_mode)){
       printf("Filename directory error found::_<>\n");
      }
   else{
  char *filename;
  char dstn_path[1000];
  filename=strrchr(store[2], '/');
  if(filename==NULL){
  strcpy(filename,store[2]);
  } else{
       filename++;
  }
  
  
  snprintf(store[i-1],1000,"%s/%s",store[i-1],filename);
  
  src_file=fopen(store[2],"r");   
    if(src_file==NULL){
       printf("Cannot read this file\n");
        //exit (0);
      }  else{
    dstn_file=fopen(store[i-1],"r");
    if(dstn_file == NULL){
   // fclose(dstn_file);
    dstn_file=fopen(store[i-1],"w");
    
     ch=fgetc(src_file);          //getting a charcacter from file1
         while(ch!=EOF){
          fputc(ch,dstn_file);   // printing character sequence in file2
          ch=fgetc(src_file);
         }
         }else{printf("File already exists\n");
           printf("Overwrite the file?(y/n): ");
           scanf("%c",&a);
           if(a=='y'){
           fclose(dstn_file);
            dstn_file=fopen(store[i-1],"w");
            ch=fgetc(src_file);          
         while(ch!=EOF){
          fputc(ch,dstn_file);   
          ch=fgetc(src_file);
         }
          } else{
                  printf("Cannot be overwritten");}
                  }
          
      fclose(src_file);
      remove(store[2]);
      fclose(dstn_file); 
      }
      
      }}
      
   else{
   src_file=fopen(store[2],"r");   
    if(src_file==NULL){
       printf("Cannot read this file file file\n");
       
      }  else{
    dstn_file=fopen(store[i-1],"r");
    if(dstn_file==NULL)
    {
        dstn_file=fopen(store[i-1],"w");
           ch=fgetc(src_file); 
       
         while(ch!=EOF){
          fputc(ch,dstn_file);   
          ch=fgetc(src_file);
          
         }
    }
    else{
    printf("Overwrite the file? (y/n): ");
    scanf("%c",&a);
     if(a=='y'){
     fclose(dstn_file); 
     dstn_file=fopen(store[i-1],"w");  
     ch=fgetc(src_file); 
       
         while(ch!=EOF){
          fputc(ch,dstn_file);   
          ch=fgetc(src_file);
          
         }}else{
         printf("Cannot be overwritten\n");
         }
         
        fclose(dstn_file); 
       }  
      fclose(src_file);
      remove(store[2]);
       }
      
  }
 } 
else if(strcmp(copy,"mv -n")==0){
struct stat prop;char *a;
if(stat(store[i-1],&prop)==0  &&  S_ISDIR(prop.st_mode)){
     if(stat(store[2],&prop) ==0 &&  S_ISDIR(prop.st_mode)){
       printf("Filename directory error found::_<>\n");
      }
   else{
  char *filename;
  char dstn_path[1000];
  filename=strrchr(store[2], '/');
  if(filename==NULL){
  strcpy(filename,store[2]);
  } else{
       filename++;
  }
  snprintf(store[i-1],1000,"%s/%s",store[i-1],filename);
  
  src_file=fopen(store[2],"r");   
    if(src_file==NULL){
       printf("Cannot read this file\n");
        
      }  else{
    dstn_file=fopen(store[i-1],"r");
    if(dstn_file == NULL){
   // fclose(dstn_file);
    dstn_file=fopen(store[i-1],"w");
    
     ch=fgetc(src_file);          //getting a charcacter from file1
         while(ch!=EOF){
          fputc(ch,dstn_file);   // printing character sequence in file2
          ch=fgetc(src_file);
         }
         }else{printf("File already exists\n");
           printf("Cannot be overwritten\n");}
        } 
      fclose(src_file);
      remove(store[2]);
      fclose(dstn_file);
      
      }}
      
   else{
   src_file=fopen(store[2],"r");   
    if(src_file==NULL){
       printf("Cannot read this file\n");
       
      }  else{
    dstn_file=fopen(store[i-1],"r");
    if(dstn_file==NULL)
    {
        dstn_file=fopen(store[i-1],"w");
           ch=fgetc(src_file); 
       
         while(ch!=EOF){
          fputc(ch,dstn_file);   
          ch=fgetc(src_file);
          
         }
    }
    else{
   
    printf("File exists..Cannot be overwritten\n");}
    fclose(dstn_file);  
         }
         
      fclose(src_file);
      remove(store[2]);
      }
      }
      
    else if(strcmp(copy,"mv -f")==0){
struct stat prop;char *a;
if(stat(store[i-1],&prop)==0  &&  S_ISDIR(prop.st_mode)){
     if(stat(store[2],&prop) ==0 &&  S_ISDIR(prop.st_mode)){
       printf("Filename directory error found::_<>\n");
      }
   else{
   remove(store[i-1]);
  char *filename;
  char dstn_path[1000];
  filename=strrchr(store[2], '/');
  if(filename==NULL){
  strcpy(filename,store[2]);
  } else{
       filename++;
  }
  
  
  snprintf(store[i-1],1000,"%s/%s",store[i-1],filename);
  
  src_file=fopen(store[2],"r");   
    if(src_file==NULL){
       printf("Cannot read this file\n");
        
      }  else{
    dstn_file=fopen(store[i-1],"r");
    if(dstn_file == NULL){
  
    dstn_file=fopen(store[i-1],"w");
    
     ch=fgetc(src_file);          //getting a charcacter from file1
         while(ch!=EOF){
          fputc(ch,dstn_file);   // printing character sequence in file2
          ch=fgetc(src_file);
         }
         }
        } 
      fclose(src_file);
      remove(store[2]);
      fclose(dstn_file);
      
      }}
      
   else{
   src_file=fopen(store[2],"r");   
    if(src_file==NULL){
       printf("Cannot read this file file file\n");
       
      }  else{
        dstn_file=fopen(store[i-1],"w");
           ch=fgetc(src_file); 
       
         while(ch!=EOF){
          fputc(ch,dstn_file);   
          ch=fgetc(src_file);
          
         }
           fclose(dstn_file);  
         }
      fclose(src_file);
      remove(store[2]);
      }
  
  }
  
  
else if(strcmp(copy,"mv -u")==0){
struct stat src;
struct stat dest;
char *a;
if(stat(store[i-1],&dest)==0  &&  S_ISDIR(dest.st_mode)){
     if(stat(store[2],&src) ==0 &&  S_ISDIR(src.st_mode)){
     
      printf("Both inputs cannot be directories\n");
      }
      else{
      printf("Destination should be a file\n");
      }
      } else{
     if(src.st_mtime<dest.st_mtime){
        if(src_file == NULL){
        printf("Cannot read file\n");}
        else{
        src_file=fopen(store[2],"r"); 
        dstn_file=fopen(store[i-1],"w");
    
     ch=fgetc(src_file);          //getting a charcacter from file1
         while(ch!=EOF){
          fputc(ch,dstn_file);   // printing character sequence in file2
          ch=fgetc(src_file);
         } 
         fclose(dstn_file);  
      }
      }
      
      fclose(src_file);
      remove(store[2]);
      
      }
      }    
 
      
      
 
 // }*/
         
else if(strcmp(store[0],"mv")==0){

struct stat prop;char a;
if(stat(store[i-1],&prop)==0  &&  S_ISDIR(prop.st_mode)){
     if(stat(store[1],&prop) ==0 &&  S_ISDIR(prop.st_mode)){
       printf("Filename directory error found::_<>\n");
      }
   else{
  char *filename;
  char dstn_path[1000];
  filename=strrchr(store[1], '/');
  if(filename==NULL){
  strcpy(filename,store[1]);
  } else{
       filename++;
  }
  
  
  snprintf(store[i-1],1000,"%s/%s",store[i-1],filename);
  
  src_file=fopen(store[1],"r");   
    if(src_file==NULL){
       printf("Cannot read this file\n");
        
      }  else{
    dstn_file=fopen(store[i-1],"r");
    if(dstn_file == NULL){
  
    dstn_file=fopen(store[i-1],"w");
    
     ch=fgetc(src_file);          //getting a charcacter from file1
         while(ch!=EOF){
          fputc(ch,dstn_file);   // printing character sequence in file2
          ch=fgetc(src_file);
         }
         }
         
        } 
      fclose(src_file);
      remove(store[1]);
      fclose(dstn_file);
      
      }}
      
   else{
   
   src_file=fopen(store[1],"r");   
    if(src_file==NULL){
       printf("Cannot read this file \n");
       
      }  else{
        dstn_file=fopen(store[i-1],"r");
           if(dstn_file==NULL){
               dstn_file=fopen(store[i-1],"w");
               ch=fgetc(src_file); 
       
               while(ch!=EOF){
                   fputc(ch,dstn_file);   
                   ch=fgetc(src_file);
          
               }
               fclose(dstn_file);
         
      
         
           }
           else{
               
               fclose(dstn_file);
               dstn_file=fopen(store[i-1],"w");
               ch=fgetc(src_file); 
       
               while(ch!=EOF){
                   fputc(ch,dstn_file);   
                   ch=fgetc(src_file);
          
               }
               fclose(dstn_file); 
           }
           fclose(src_file);
           remove(store[1]);
        
     }   
      }
  
  }
  
      
      
   
      
   }    
       
       
    
    
    
    
    
