#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<unistd.h>


int main(){
	char hostname[100];
        fgets(hostname, 100,stdin );
		return 0;
		
}
